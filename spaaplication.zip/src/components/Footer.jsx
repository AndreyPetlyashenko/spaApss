const Footer= () => {
    return (
        <div className="footer">
            <h5>The App was made by Andrii Petliashenko</h5>
        </div>
    )
}
export default Footer